package com.exam.springexam.model.entity;

public enum CategoryName {
    FOOD,
    DRINK,
    HOUSEHOLD,
    OTHER;
}
